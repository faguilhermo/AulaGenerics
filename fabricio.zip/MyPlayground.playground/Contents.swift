import Foundation

var intA = 1
var intB = 2
let maiorInt = maior(intA, intB)

var doubleA = Double.pi
var doubleB = 3.14
let maiorDouble =  maior(doubleA, doubleB)

var tratorA = AgriculturalMachinery(size: 12)
var tratorB = AgriculturalMachinery(size: 783)
let maiorTrator = maior(tratorA, tratorB)

var pilha = Pilha<Int>()

pilha.push(intA)
pilha.push(intB)

//TODO: Fazer um método que recebe um Array e um elemento, retorna um Bool dizendo se o elemento se encontra no Array
public func elementExist<Element: Comparable>(_ array: [Element], _ element: Element) -> Bool {
    for index in array {
        if index == element {
            return true
        }
    }
    return false
}

//TODO: Extensão de Array contendo uma função que retorna a soma de todos os elementos, independente de qual o valor numérico
extension Array where Element: Numeric {
    public func addArray(_ array: [Element]) -> Element {
        var total = Element.zero
        for index in array {
            total += index
        }
        return total
    }
}

//TODO: Fazer um método que recebe 2 Arrays e retorna um Int referente a quantidade de elementos presentes em ambos os Arrays
public func intersection<Element: Comparable>(_ array1: [Element], _ array2: [Element]) -> Int {
    var total = 0
    for i in array1 {
        for j in array2 {
            if i == j { total += 1 }
        }
    }
    return total
}
    //BONUS TODO: Fazer o método acima receber N arrays\
        // EM BREVE
